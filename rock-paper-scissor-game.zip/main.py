import random
ls=["rock",'paper',"scissor"]
c=random.choice(ls)
u=input("chose between rock,paper and scissor")
if((c=="rock" and u=="paper") or(c=="paper" and u=="scissor") or(c=="scissor" and u=='rock')):
 print("you win")
elif(u==c):
 print("it is a tie")
else:
 print("you lose")